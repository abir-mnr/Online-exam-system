 </section>
<section class="footeroption">
		<h2><?php echo "All rights reserved &copy Abir"; ?></h2>
	</section>
</div>
</body>
</html>