<?php
define("DB_HOST", "fdb23.awardspace.net");
define("DB_USER", "2819247_onlineexam");
define("DB_PASS", "abir99242625");
define("DB_NAME", "2819247_onlineexam");
